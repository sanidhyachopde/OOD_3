import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class BST_DupTree_Test {

	static DupTree dtr;
	static List<Integer> al = new ArrayList<Integer>();
	static Random r = new Random();

	@BeforeAll
	public static void setup() {
	 	// code to be filled in by you
		for(int i = 0; i < 25; i++)
		{
			int ran = r.nextInt(25);
			
			if(dtr == null)
				dtr = new DupTree(ran);
			else
				dtr.insert(ran);
			
			al.add(new Integer(ran));
		}	
		//for(Iterator i = dtr.iterator(); i <)
		System.out.println("DupTree created in Setup: " );
		Iterator iter1 = dtr.iterator();
		
		while(iter1.hasNext())
			System.out.print(iter1.next()+" ");
		
		System.out.println();
		System.out.println("Sorted ArrayList created in Setup: " );
		
		Collections.sort(al);
		
		for(int i=0; i< al.size();i++)
			System.out.print(al.get(i)+" ");
		
		System.out.println();
		System.out.println("----------------------------");
	}

	@AfterEach
	void check_invariant() {
		// code to be filled in by you
		assertTrue(ordered(dtr));
		System.out.println("DupTree invariant maintained");
		System.out.println("----------------------------");
	}
	
	@Test
	void test_insert() {
		// code to be filled in by you 
		Iterator iter1 = dtr.iterator();
		Iterator iter2 = al.iterator();
		System.out.println("Testing DupTree insert ..." );
		System.out.println("Creating ArrayList iterator and Comparing elements pair-wise ...");
		while(iter1.hasNext() && iter2.hasNext())
		{
			
			assertEquals(iter1.next(),iter2.next());
			//iter1.next();
			//iter2.next();
			
		}
		System.out.println("... DupTree insert test passed");
	}
	
	@Test
	void test_delete() {
		// code to be filled in by you
		int v = r.nextInt(25);
		//v = v/25; 
		//System.out.println("before"+get_count(dtr,v));
		
		if(dtr == null)
			dtr = new DupTree(v);
		else
			dtr.insert(v);
		//dtr.insert(v);
		int countOfV = get_count(dtr,v);
		System.out.println("Testing DupTree delete: inserted value = "+v+ " with count = "+countOfV);
		//System.out.println("CountOfV"+countOfV);
		dtr.delete(v);
		int afterCount = 0;
		
		if(dtr != null)
			afterCount = get_count(dtr,v);
		
		System.out.println("After DupTree delete: value = "+v+ " with count = "+afterCount);
			
		//else
		//System.out.println("afterCount"+afterCount);
		assertEquals(countOfV-1,afterCount);
		System.out.println("DupTree delete test passed");
	}		

	public int get_count(DupTree tr, int v) {
		// code to be filled in by you 
		return tr.find(v)==null ? 0 : tr.find(v).get_count(); //Added By SAIANAND
	}

	public boolean ordered(Tree tr) {
		// code to be filled in by you
		return (tr.left == null || (tr.value > tr.left.max().value && ordered(tr.left)) && 
				(tr.right == null || (tr.value < tr.right.min().value && ordered(tr.right))) );
	}
}